USE hr_analytics;
SELECT * FROM hr_1;
DESCRIBE hr_1;
set sql_safe_updates =0;
ALTER TABLE hr_1 
DROP COLUMN AttritionConut;
ALTER TABLE hr_1 ADD AttritionCount int;
 
UPDATE hr_1
SET AttritionCount = CASE WHEN Attrition = "YES" THEN 1 ELSE 0 END;

# Total Employees
SELECT COUNT(EmployeeNumber) AS Total_Employee FROM hr_1;

# Total Attrition

SELECT SUM(AttritionCount) AS Total_Attrition FROM hr_1;
#OR

SELECT SUM( CASE WHEN Attrition = "Yes" THEN 1 ELSE 0 END) AS Attrition_Count
FROM hr_1;

# Active Employees
SELECT SUM( CASE WHEN Attrition="No" THEN 1 ELSE 0 END)  AS Active_Employees
FROM hr_1;

# Attrition Rate(%)

SELECT CONCAT(ROUND(SUM(AttritionCount)*100.0/COUNT(*),2),"%") AS Attrition_Rate FROM hr_1;

SELECT CONCAT(ROUND((SUM( CASE WHEN Attrition = "Yes" THEN 1 ELSE 0 END)*100.0)/COUNT(*),2),"%") AS Attrition_Rate
FROM hr_1;

# KPI 1.. Attrition rate for all Departments
SELECT Department,
CONCAT(ROUND(SUM(AttritionCount)*100.0/COUNT(*),2),"%") AS Attrition_Rate 
FROM hr_1
GROUP BY Department;

# KPI  2..Avearage_Hourly_Rate for Male Research Scientist
SELECT JobRole,AVG(HourlyRate) AS Avearage_Hourly_Rate
FROM hr_1
WHERE JobRole = "Research Scientist"
AND Gender = "Male";

# KPI 3..Attrition rate Vs Monthly income stats
SELECT hr_1.Department,ROUND(AVG(hr_2.MonthlyIncome),2) AS Monthly_Income,CONCAT(ROUND(SUM(AttritionCount)*100.0/COUNT(*),2),"%") AS Attrition_Rate 
FROM  hr_1 
JOIN hr_2  ON hr_1.EmployeeNumber=hr_2.EmployeeID
GROUP BY hr_1.Department;

# KPI 4.. Job Role Vs Work life balance
SELECT hr_1.JobRole,ROUND(AVG(hr_2.WorkLifeBalance),2) AS Work_Life_Balance
FROM hr_1 
JOIN  hr_2 ON hr_1.EmployeeNumber=hr_2.EmployeeID
GROUP BY hr_1.JobRole;

# KPI 5..Average working years for each Department
SELECT  hr_1.Department,ROUND(AVG(hr_2.TotalWorkingYears),2) AS Average_Working_Years
FROM hr_1
JOIN hr_2 ON hr_1.EmployeeNumber = hr_2.EmployeeID
GROUP BY hr_1.Department;

# Attrition Rate for Age Range

SELECT CASE 
WHEN Age BETWEEN 0 AND 20 THEN "0-20"
WHEN Age BETWEEN 21 AND 30 THEN "20-30"
WHEN Age BETWEEN 31 AND 40 THEN "30-40"
WHEN Age BETWEEN 41 AND 50 THEN "40-50"
WHEN Age BETWEEN 51 AND 60 THEN "50-60"
ELSE "60+" END AS Age_Range,COUNT(*) AS Total_Employees,
CONCAT(ROUND(SUM(AttritionCount)*100.0/COUNT(*),2),"%") AS Attrition_Rate 
FROM hr_1
GROUP BY Age_Range
ORDER BY Age_Range ASC;

# No. Marital Status
SELECT MaritalStatus,COUNT(*) AS Total_Number,
CONCAT(ROUND(SUM(AttritionCount)*100.0/COUNT(*),2),"%") AS Attrition_Rate 
FROM hr_1
GROUP BY MaritalStatus;


SELECT MAX(MonthlyIncome) AS Highest_Income
FROM hr_2;

SELECT MIN(MonthlyIncome) AS Highest_Income
FROM hr_2;

SELECT MAX(MonthlyIncome) AS Second_Highest_Income
FROM hr_2
WHERE MonthlyIncome < (SELECT MAX(MonthlyIncome) FROM hr_2);


# Highest Monthly Incomme For all Department


 SELECT 
    t.Department,
    t.MonthlyIncome AS Highest_Income
FROM (
    SELECT 
        hr_1.Department,
        hr_2.MonthlyIncome,
        DENSE_RANK() OVER (PARTITION BY hr_1.Department ORDER BY hr_2.MonthlyIncome DESC) AS rnk
    FROM hr_1
    JOIN hr_2 ON hr_1.EmployeeNumber = hr_2.EmployeeID
) AS t
WHERE t.rnk = 1;


 
# Created View (Emp_Info)
CREATE VIEW Emp_Info AS 
SELECT EmployeeNumber,Age,Education,MaritalStatus,Gender FROM hr_1;

SELECT * FROM Emp_Info;




